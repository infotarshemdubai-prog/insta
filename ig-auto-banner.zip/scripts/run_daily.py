"""
run_daily.py
Runs the full daily flow for every enabled business:
  1. Generate today's banner
  2. Build the raw.githubusercontent.com URL for the committed image
     (the GitHub Actions workflow commits the image BEFORE this script's
      posting step runs, so the URL is live by the time we call the API)
  3. Post it to Instagram with an auto-generated caption

Environment variables expected (set by the workflow):
    GITHUB_REPOSITORY   e.g. "tarsem/ig-auto-banner"
    GITHUB_REF_NAME     e.g. "main"
"""

import os
import sys
import json
import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from generate_banner import generate, load_config, pick_quote
from post_to_instagram import post

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def raw_url(repo, branch, path_in_repo):
    return f"https://raw.githubusercontent.com/{repo}/{branch}/{path_in_repo}"


def main():
    with open(os.path.join(ROOT, "config", "businesses.json")) as f:
        businesses = json.load(f)["businesses"]

    repo = os.environ.get("GITHUB_REPOSITORY", "")
    branch = os.environ.get("GITHUB_REF_NAME", "main")
    today = datetime.date.today()

    for b in businesses:
        if not b.get("enabled", True):
            continue

        rel_path = f"output/{b['id']}_{today}.jpg"
        out_path = os.path.join(ROOT, rel_path)
        generate(b["id"], out_path)

        if not repo:
            print(f"[{b['id']}] GITHUB_REPOSITORY not set — skipping post (local test mode).")
            continue

        image_url = raw_url(repo, branch, rel_path)
        quote = pick_quote(b["quote_file"])
        caption = (
            f"{quote}\n\n"
            f"#{b['id'].replace('_', '')} #motivation #dubai #business"
        )

        try:
            post(b["id"], image_url, caption)
        except Exception as e:
            print(f"[{b['id']}] FAILED to post: {e}")


if __name__ == "__main__":
    main()
