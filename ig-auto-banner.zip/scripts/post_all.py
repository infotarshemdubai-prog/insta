"""
post_all.py — posting-only step, run AFTER the day's banners have been
committed and pushed (so raw.githubusercontent.com URLs are live).
"""

import os
import sys
import json
import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from generate_banner import pick_quote
from post_to_instagram import post

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def raw_url(repo, branch, path_in_repo):
    return f"https://raw.githubusercontent.com/{repo}/{branch}/{path_in_repo}"


def main():
    with open(os.path.join(ROOT, "config", "businesses.json")) as f:
        businesses = json.load(f)["businesses"]

    repo = os.environ.get("GITHUB_REPOSITORY", "")
    branch = os.environ.get("GITHUB_REF_NAME", "main")
    today = datetime.date.today()

    if not repo:
        print("GITHUB_REPOSITORY not set — cannot build public image URL. Aborting posts.")
        return

    for b in businesses:
        if not b.get("enabled", True):
            continue

        rel_path = f"output/{b['id']}_{today}.jpg"
        image_url = raw_url(repo, branch, rel_path)
        quote = pick_quote(b["quote_file"])
        caption = f"{quote}\n\n#{b['id'].replace('_', '')} #motivation #dubai #business"

        try:
            post(b["id"], image_url, caption)
        except Exception as e:
            print(f"[{b['id']}] FAILED to post: {e}")


if __name__ == "__main__":
    main()
