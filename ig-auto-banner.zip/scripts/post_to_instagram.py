"""
post_to_instagram.py
Publishes an already-generated banner image to a business's Instagram
account via the Instagram Graph API.

IMPORTANT: The Graph API needs the image at a PUBLIC https URL — it
cannot accept a raw file upload. In the GitHub Actions workflow, the
banner is committed to the repo and served via the raw.githubusercontent.com
URL, which is passed in here.

Requires per business (as env vars, see config/businesses.json for the
exact names):
    <BUSINESS>_IG_USER_ID    -> Instagram Business Account ID
    <BUSINESS>_IG_TOKEN      -> long-lived Page Access Token with
                                 instagram_content_publish permission

Usage:
    python post_to_instagram.py <business_id> <image_public_url> <caption>
"""

import os
import sys
import json
import time
import argparse
import requests

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GRAPH_VERSION = "v21.0"


def load_config(business_id):
    with open(os.path.join(ROOT, "config", "businesses.json")) as f:
        data = json.load(f)
    for b in data["businesses"]:
        if b["id"] == business_id:
            return b
    raise ValueError(f"Business '{business_id}' not found in config/businesses.json")


def post(business_id, image_url, caption):
    cfg = load_config(business_id)
    ig_user_id = os.environ.get(cfg["ig_business_account_id_env"])
    access_token = os.environ.get(cfg["ig_access_token_env"])

    if not ig_user_id or not access_token:
        raise EnvironmentError(
            f"Missing env vars {cfg['ig_business_account_id_env']} / "
            f"{cfg['ig_access_token_env']}. Set them as GitHub Actions secrets."
        )

    base = f"https://graph.facebook.com/{GRAPH_VERSION}/{ig_user_id}"

    # Step 1: create media container
    r1 = requests.post(f"{base}/media", data={
        "image_url": image_url,
        "caption": caption,
        "access_token": access_token,
    })
    r1.raise_for_status()
    creation_id = r1.json()["id"]
    print(f"Media container created: {creation_id}")

    # Step 2: poll container status until it's ready
    status_url = f"https://graph.facebook.com/{GRAPH_VERSION}/{creation_id}"
    for _ in range(10):
        status = requests.get(status_url, params={
            "fields": "status_code",
            "access_token": access_token,
        }).json()
        if status.get("status_code") == "FINISHED":
            break
        time.sleep(3)

    # Step 3: publish
    r2 = requests.post(f"{base}/media_publish", data={
        "creation_id": creation_id,
        "access_token": access_token,
    })
    r2.raise_for_status()
    result = r2.json()
    print(f"Published: {result}")
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("business_id")
    parser.add_argument("image_url")
    parser.add_argument("caption")
    args = parser.parse_args()
    post(args.business_id, args.image_url, args.caption)
