"""
generate_all.py — generation-only step (no posting).
Called BEFORE the git commit in the workflow, so the images exist on
disk and get pushed to the repo before post_all.py tries to reference
their public raw.githubusercontent.com URLs.
"""

import os
import sys
import json
import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from generate_banner import generate

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main():
    with open(os.path.join(ROOT, "config", "businesses.json")) as f:
        businesses = json.load(f)["businesses"]

    today = datetime.date.today()
    for b in businesses:
        if not b.get("enabled", True):
            continue
        rel_path = f"output/{b['id']}_{today}.jpg"
        out_path = os.path.join(ROOT, rel_path)
        generate(b["id"], out_path)


if __name__ == "__main__":
    main()
