"""
generate_banner.py
Generates a 1080x1080 motivational banner image for a given business config.

Usage:
    python generate_banner.py <business_id> [--out output/banner.jpg]

Reads config/businesses.json, picks a quote (day-of-year based, so it
rotates automatically and never repeats until the pool cycles), and
draws a clean branded banner.
"""

import json
import os
import sys
import argparse
import datetime
import textwrap
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FONT_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FONT_REG = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"

SIZE = 1080


def load_config(business_id):
    with open(os.path.join(ROOT, "config", "businesses.json")) as f:
        data = json.load(f)
    for b in data["businesses"]:
        if b["id"] == business_id:
            return b
    raise ValueError(f"Business '{business_id}' not found in config/businesses.json")


def pick_quote(quote_file):
    path = os.path.join(ROOT, quote_file)
    with open(path) as f:
        quotes = json.load(f)["quotes"]
    day_index = datetime.date.today().timetuple().tm_yday
    return quotes[day_index % len(quotes)]


def hex_to_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def draw_gradient(draw, top_color, bottom_color):
    for y in range(SIZE):
        t = y / SIZE
        r = int(top_color[0] + (bottom_color[0] - top_color[0]) * t)
        g = int(top_color[1] + (bottom_color[1] - top_color[1]) * t)
        b = int(top_color[2] + (bottom_color[2] - top_color[2]) * t)
        draw.line([(0, y), (SIZE, y)], fill=(r, g, b))


def wrap_text_to_fit(draw, text, font, max_width):
    words = text.split()
    lines, current = [], ""
    for w in words:
        test = (current + " " + w).strip()
        if draw.textlength(test, font=font) <= max_width:
            current = test
        else:
            if current:
                lines.append(current)
            current = w
    if current:
        lines.append(current)
    return lines


def generate(business_id, out_path):
    cfg = load_config(business_id)
    quote = pick_quote(cfg["quote_file"])

    brand = hex_to_rgb(cfg["brand_color"])
    accent = hex_to_rgb(cfg["accent_color"])
    bottom = tuple(max(0, c - 30) for c in brand)

    img = Image.new("RGB", (SIZE, SIZE), brand)
    draw = ImageDraw.Draw(img)
    draw_gradient(draw, brand, bottom)

    # Soft accent bar at top
    draw.rectangle([0, 0, SIZE, 14], fill=accent)

    # Quote text, auto-sized to fit
    font_size = 68
    quote_font = ImageFont.truetype(FONT_BOLD, font_size)
    max_width = SIZE - 160
    lines = wrap_text_to_fit(draw, quote, quote_font, max_width)
    while len(lines) > 5 and font_size > 36:
        font_size -= 4
        quote_font = ImageFont.truetype(FONT_BOLD, font_size)
        lines = wrap_text_to_fit(draw, quote, quote_font, max_width)

    line_height = int(font_size * 125 / 1000 * 10)
    total_text_height = line_height * len(lines)
    y = (SIZE - total_text_height) // 2 - 40

    # Opening quote mark
    mark_font = ImageFont.truetype(FONT_BOLD, 140)
    draw.text((80, y - 130), "\u201C", font=mark_font, fill=accent)

    for line in lines:
        w = draw.textlength(line, font=quote_font)
        x = (SIZE - w) // 2
        draw.text((x, y), line, font=quote_font, fill="white")
        y += line_height

    # Divider
    div_y = y + 30
    draw.line([(SIZE // 2 - 60, div_y), (SIZE // 2 + 60, div_y)], fill=accent, width=4)

    # Business name + handle at bottom
    name_font = ImageFont.truetype(FONT_BOLD, 42)
    handle_font = ImageFont.truetype(FONT_REG, 30)

    name = cfg["display_name"]
    handle = cfg.get("handle", "")

    name_w = draw.textlength(name, font=name_font)
    draw.text(((SIZE - name_w) // 2, SIZE - 160), name, font=name_font, fill=accent)

    if handle:
        handle_w = draw.textlength(handle, font=handle_font)
        draw.text(((SIZE - handle_w) // 2, SIZE - 105), handle, font=handle_font, fill="white")

    # Optional logo (top-left corner), if the file exists
    logo_path = os.path.join(ROOT, cfg.get("logo", ""))
    if cfg.get("logo") and os.path.exists(logo_path):
        logo = Image.open(logo_path).convert("RGBA")
        logo.thumbnail((120, 120))
        img.paste(logo, (40, 40), logo)

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    img.save(out_path, "JPEG", quality=92)
    print(f"Banner saved: {out_path}")
    print(f"Quote used: {quote}")
    return out_path


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("business_id")
    parser.add_argument("--out", default=None)
    args = parser.parse_args()

    out = args.out or os.path.join(ROOT, "output", f"{args.business_id}_{datetime.date.today()}.jpg")
    generate(args.business_id, out)
