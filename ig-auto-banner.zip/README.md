# Daily Instagram Motivational Banner — Setup Guide

Ye system har roz ek motivational banner khud generate kar ke aapke
Instagram business account(s) pe post kar deta hai — koi manual kaam nahi.

## Kya kya hai isme
- `config/businesses.json` — har business ki details (naam, colors, logo, IG account)
- `quotes/quotes_general.json` — motivational lines ka pool (aap add/remove kar sakte hain)
- `scripts/generate_banner.py` — ek banner banata hai
- `scripts/post_to_instagram.py` — ek banner post karta hai
- `.github/workflows/daily-post.yml` — roz automatic chalata hai (GitHub Actions)

## Setup — 5 steps

### 1. GitHub repo banayein
- Ye poora folder ek naye **public** GitHub repo mein push kar dein
  (public isliye zaroori hai kyunki Instagram ko image ka public URL chahiye —
  private repo ka raw link Instagram access nahi kar sakta)

### 2. Har business ke liye Instagram Business Account ID aur Access Token lein
Ye same process hai jo aapne pehle DXB Mobile Hub ke Instagram agent ke liye follow ki thi:
1. Meta Business Manager > Business Settings > System User (ya App) banayein
2. Instagram Business Account ko Facebook Page se link karein
3. Graph API Explorer se ya App se **long-lived Page Access Token** generate karein
   (permissions: `instagram_basic`, `instagram_content_publish`, `pages_read_engagement`)
4. Instagram Business Account ID nikalein:
   `GET https://graph.facebook.com/v21.0/{page-id}?fields=instagram_business_account&access_token={token}`

### 3. GitHub repo mein Secrets add karein
Repo > Settings > Secrets and variables > Actions > New repository secret:

| Secret name | Value |
|---|---|
| `NEXORA_MOBILE_IG_USER_ID` | Instagram Business Account ID |
| `NEXORA_MOBILE_IG_TOKEN` | Long-lived access token |
| `KHAT_AL_MIZAN_IG_USER_ID` | (agar ye bhi chalana hai) |
| `KHAT_AL_MIZAN_IG_TOKEN` | (agar ye bhi chalana hai) |

Naya business add karna ho to `config/businesses.json` mein entry add karein
aur uske naam ke 2 secrets bhi add kar dein.

### 4. Logo (optional)
`assets/` folder mein business ka logo PNG (transparent background) daal dein,
aur config mein `"logo"` path already set hai.

### 5. Time zone / schedule set karein
`.github/workflows/daily-post.yml` mein cron `"0 4 * * *"` hai — ye
04:00 UTC = subah 8:00 baje Dubai time hai. Badalna ho to cron time change kar dein.

## Test karna
- GitHub repo > Actions tab > "Daily Instagram Motivational Banner" > **Run workflow**
  button se manually chala ke test kar sakte hain, cron ka wait kiye bina.

## Disable / pause karna
`config/businesses.json` mein us business ka `"enabled": false` kar dein —
tab wo skip ho jayega, baaki chalte rahenge.

## Naya business add karna
`config/businesses.json` mein naya block copy-paste karein, `id`, naam,
colors, aur env var names badal dein, phir GitHub secrets add kar dein.
